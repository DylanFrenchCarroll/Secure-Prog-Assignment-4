module.exports = {
    hostname: '127.0.0.1',
    port: 3000,
    someFunction: function(){
        console.log("Custom logic here");
    }
};