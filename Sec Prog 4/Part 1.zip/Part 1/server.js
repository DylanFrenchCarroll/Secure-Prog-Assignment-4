const express = require('express');
const config = require('./config.js');
const app = express()
const port = config.port;
const path = require('path');

app.get('/', function(req,res){
  res.sendFile(path.join(__dirname + '/../HTML/index.html'))
})


app.get('/jsonData', function(req,res){
 fs.readFile('names.json', function(err, content){
   if (err) throw err;
   var parseJson = JSON.parse(content);
   var jstr = JSON.stringify(parseJson);
   res.write('<h1><a href="/"> Return </a> </h1>');
   res.write(jstr);
   res.end;
 })
})

var bodyParser = require ('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));



var fs = require ('fs');
app.post('/postForm', function(req, res){
 let Name = req.body.name;
 console.log(Name);

var obj = {
  table:[]
};

/*
obj.table.push({id:Name});
var json = JSON.stringify(obj);
fs.writeFile('names.json', json, function(err){
  if (err) throw err;
})
*/

fs.readFile('names.json', function(err, content){
  if(err) throw err;
  var parseJson = JSON.parse(content);

  parseJson.table.push({id: Name})
  var jstr = JSON.stringify(parseJson)
  fs.writeFile('names.json', jstr, function(err){
    if (err) throw err;
  })
  res.json(parseJson);
  
})

})

app.listen(port, () => console.log('Application running on localhost, port: ${port}'))
