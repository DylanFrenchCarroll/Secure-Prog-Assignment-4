const express = require('express');
const config = require('./config.js');
const app = express()
const port = config.port;
const path = require('path');


//get index
app.get('/', function(req,res){
  res.sendFile(path.join(__dirname + '/../Part 4/index.html'))
})

//parsing json data and displaying it
app.get('/jsonData', function(req,res){
 fs.readFile('names.json', function(err, content){
   if (err) throw err;
   var parseJson = JSON.parse(content);
   var jstr = JSON.stringify(parseJson);
   res.write('<h1><a href="/"> Return </a> </h1>');
   res.write(jstr);
   res.end;
 })
})

var bodyParser = require ('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
var fs = require ('fs');


//validate name length
function validateLength(validLengthName){
  var length = validLengthName.length;    //if length is greate than 8 return false
  if(length> 8){
    return false;
  }
  else{
    return true;
  }
}

//validate that name is not empty
function validateEmpty(validName) {
  if (validName == "" || validName == null) {
    console.log('empty form')
    return false; //if false exits else continues
  }
  else{
    return true;
  }
}

//Regex validation for name and email
function validateRegex(rgName){
  var regex = /[A-Za-z]/g;
  var result = regex.test(rgName);
  console.log(result);
  return result; //if false exits else continues
}
function validateEmailRegex(rgEmail){
  var regex = /@/g;
  var result = regex.test(rgEmail);
  console.log(result);
  return result; //if false exits else continues

}



//main post method
app.post('/postForm', function(req, res){
 let Name = req.body.name;
 let EMail = req.body.email;
 console.log(Name.length);
 
 validateRegex(Name);
 validateEmailRegex(EMail);
 validateEmpty(Name);
 validateEmpty(EMail);
 validateLength(Name);

 

var obj = {
  table:[]
};

/*
obj.table.push({id:Name,x:EMail});
var json = JSON.stringify(obj);
fs.writeFile('names.json', json, function(err){
  if (err) throw err;
})
*/


fs.readFile('names.json', function(err, content){
  if(err) throw err;
  var parseJson = JSON.parse(content);

  parseJson.table.push({id: Name, x:EMail})
  var jstr = JSON.stringify(parseJson)
  fs.writeFile('names.json', jstr, function(err){
    if (err) throw err;
  })
  res.json(parseJson);

})

})

app.listen(port, () => console.log('Application running on localhost, port: ${port}'))
