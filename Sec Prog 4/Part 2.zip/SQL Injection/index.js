const express = require('express');
const db = require('./config.js');
const conn = db()
var bodyParser = require('body-parser')
const app = express()
const path = require('path');

conn.connect((err) => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

app.use(express.json());
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended : true }));
 app.use(bodyParser.urlencoded());
 app.use(bodyParser.json());


app.get('/', function(req,res){
    res.sendFile(path.join(__dirname + '/../node-04/index.html'))
  })

app.get('/tables', function (req, res) {
    let sql = "SELECT * FROM people;";
    let query = conn.query(sql, [], (err, results) => {
        if (err) {
            res.json({
                data: err
            })
        }
        else {
            res.json({
                data: results
            })
        }
    });
})

app.get('/table/:name', function (req, res) {
    let sql = `DESCRIBE ${req.params.name}`;
    let query = conn.query(sql, [], (err, results) => {
        if (err) {
            res.json({
                data: err
            })
        }
        else {
            res.json({
                data: results
            })
        }
    });
})

//server listening
app.listen(3000, () => {
    console.log('Server is running at port ' + 3000);
});

app.post('/postForm', function(req, res){

    let Username = req.body.username;
    let Password = req.body.password;

    console.log(Username);


 var sql = "SELECT * FROM people WHERE name ='" + Username + "';";
 console.log(sql);
 
    let query = conn.query(sql, [], (err, results) => {
        if (err) {
            res.send('Nothing to return')
        }
        else {
            res.json({
                data: results
            })
        }
    });
    

})

module.exports = app





