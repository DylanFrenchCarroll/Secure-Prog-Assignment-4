var mysql = require('mysql');
var db = null;

module.exports = function () {
    if (!db) {
        db = mysql.createConnection({
            host: 'localhost',
            port: '3306',
            user: 'root',
            password: 'root',
            database: 'secureprog'
        });
    }
    return db;
};